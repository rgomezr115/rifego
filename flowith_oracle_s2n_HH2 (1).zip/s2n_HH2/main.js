/**
 * RIFEGO Main Interaction Logic
 */

document.addEventListener('DOMContentLoaded', () => {

    lucide.createIcons();


    const heroTl = gsap.timeline({ defaults: { ease: 'power3.out', duration: 1 } });
    
    heroTl.to('.hero-content h1', { opacity: 1, y: 0, delay: 0.5 })
          .to('.hero-content p', { opacity: 1, y: 0 }, '-=0.7')
          .to('.hero-content .flex', { opacity: 1, y: 0 }, '-=0.7')
          .to('.hero-content .inline-flex', { opacity: 1, y: 0 }, '-=1');


    gsap.registerPlugin(ScrollTrigger);

    const revealElements = document.querySelectorAll('.service-card, h2, h3, .service-card');
    
    revealElements.forEach((el) => {
        gsap.from(el, {
            scrollTrigger: {
                trigger: el,
                start: 'top 85%',
                toggleActions: 'play none none none'
            },
            opacity: 0,
            y: 30,
            duration: 0.8,
            ease: 'power2.out'
        });
    });


    gsap.to('#inicio img', {
        scrollTrigger: {
            trigger: '#inicio',
            start: 'top top',
            end: 'bottom top',
            scrub: true
        },
        y: 100,
        scale: 1.1
    });


    const nav = document.querySelector('nav');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            nav.classList.add('py-2', 'shadow-sm');
            nav.classList.remove('h-20');
        } else {
            nav.classList.remove('py-2', 'shadow-sm');
            nav.classList.add('h-20');
        }
    });


    const menuBtn = document.getElementById('mobile-menu-btn');
    menuBtn.addEventListener('click', () => {
        alert('Navegación móvil: Inicio | Nosotros | Productos | Servicios | Contacto');
    });


    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const btn = contactForm.querySelector('button');
            const originalText = btn.innerText;
            
            btn.innerText = 'Enviando...';
            btn.disabled = true;
            btn.classList.add('opacity-50');

            setTimeout(() => {
                btn.innerText = '¡Enviado con Éxito!';
                btn.classList.remove('bg-red-600');
                btn.classList.add('bg-green-600');
                
                setTimeout(() => {
                    btn.innerText = originalText;
                    btn.classList.remove('bg-green-600', 'opacity-50');
                    btn.classList.add('bg-red-600');
                    btn.disabled = false;
                    contactForm.reset();
                }, 3000);
            }, 1500);
        });
    }


    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('load', () => {
            img.style.opacity = '1';
        });
    });
});
